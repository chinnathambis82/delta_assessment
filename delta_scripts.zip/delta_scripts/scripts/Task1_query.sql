Task 1:
Get the latest flight details from Flight Leg Table:

select flightkey,flightnum,
flight_dt, orig_arpt,dest_arpt,
flightstatus,lastupdt
from 
(select flightkey,flightnum,
flight_dt, orig_arpt,dest_arpt,
flightstatus,lastupdt,
row_number() OVER (PARTITION BY flightkey order by lastupdt desc) row_num
from FlightLeg ) A
where row_num=1