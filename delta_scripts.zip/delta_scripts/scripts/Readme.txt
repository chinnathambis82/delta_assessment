Read_me document:
Task 1:
1. Task1_query.sql (Get the latest details for each flight using SQL)

Task 2:
-------

STEP 1:
--------
Data Clean up using Shell
--------------------------
As the input file has unwanted information which we need to eliminate from the files.
store the scripts in /delta_scripts/scripts/
keep the input file dummy_flight_leg_data.csv in the same folder
run the below command to remove the unwanted first 8 lines and last 2 lines
Command: 
/delta/scripts/delete_unwanted_lines.sh /delta_scripts/scripts/Dummy_Flight_Leg_Data.csv


STEP 2: 
-------
Python process to ingest and query the data
--------------------------------------------
Install the psycopg2 for Python
pip install psycopg2
Save the json file "db_conn.json" (Update the Json file with right DB Information)

Execution of Python
-------------------
python Task2_flight.py
'Enter the data file full path:' /delta_scripts/scripts/Dummy_Flight_Leg_Data.csv
'Enter the Db Connection Json:' /delta_scripts/scripts/db_conn.json


