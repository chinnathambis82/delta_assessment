#!/bin/bash

# Check if file path is provided as parameter
if [ -z "$1" ]; then
  echo "Please provide the file path as a parameter."
  exit 1
fi

# Check if the file exists
if [ ! -f "$1" ]; then
  echo "File does not exist."
  exit 1
fi

# Get the total number of lines in the file
total_lines=$(wc -l < "$1")

# Calculate the number of lines to skip
lines_to_skip=$((8 + 2))

# Calculate the number of lines to keep
lines_to_keep=$((total_lines - lines_to_skip))

# Delete the first 8 lines and the last 2 lines of the file
tail -n "+$lines_to_skip" "$1" | head -n "$lines_to_keep" > "$1.temp"

# Overwrite the original file with the modified contents
mv "$1.temp" "$1"

echo "First 8 lines and last 2 lines deleted successfully from $1."