import os
import psycopg2
import pandas as pd
import json

#Get the input file name with full path and validate whether we have the file or not
input_file_full_path =input('Enter the data file full path:')
print("Enter fileName : "+input_file_full_path)
#Check if the file exists or not
if os.path.exists(input_file_full_path):
    print("Valid input file")
else:
    raise FileNotFoundError("No such file")

#Get the  Db Connection JSON file with full path and validate whether we have the file or not
db_conn_file = input("Enter the Db Connection Json file path")
if os.path.exists(db_conn_file):
    print("Valid input file")
else:
    raise FileNotFoundError("No such file for DB Connection")

with open(db_conn_file) as file:
    db_data = json.load(file)

# Extract the connection details
host = data['host']
port = data['port']
database = data['database']
user = data['user']
password = data['password']

# Create the connection to Postgres DB
conn = psycopg2.connect(
    host=host,
    port=port,
    database=database,
    user=user,
    password=password
)
# set auto commit to True
conn.autocommit=True
#Create table SQL Script
create_tbl='''Create table IF NOT EXISTS ASSESSMENT.FLIGHT_LEG(\
              carrier_code Varchar(3) NOT NULL,\
              flight_dt date NOT NULL,\
              flight_num int NOT NULL, \
              orig_arpt Varchar(4) NOT NULL, \
              dest_arpt Varchar(4) NOT NULL, \
              flight_status Varchar(20) ,\
              last_updt time NOT NULL, \
              flight_key Varchar(20) NOT NULL);'''
#Create the table if not exists
cursor = conn.cursor()
try:
    cursor.execute(create_tbl)
except (Exception, psycopg2.DatabaseError) as error:
    print("Error : %s" %error)
    cursor.close()
    raise error

cursor.execute('''set datestyle "iso, mdy";''')
date_format='MM/DD/YY'
time_format='HH:MI'
#Now ingest the data
copy_sql =f"Copy ASSESSMENT.FLIGHT_LEG(carrier_code,flight_dt,flight_num,orig_arpt,dest_arpt,flight_status,last_updt,flight_key) FROM %s DELIMITER ',' CSV HEADER false  DATEFORMAT '{date_format}' TIMEFORMAT '{time_format}'"
try:
    cursor.execute(copy_query, (input_file_full_path,))
    conn.commit()
except (Exception, psycopg2.DatabaseError) as error:
    print("Error : %s" %error)
    cursor.close()
    raise error

cursor.close()
#Generate the output from the table to pandas DF and generate row_number and filter the first record
column_names=["carrier_code","flight_dt","flight_num","orig_arpt","dest_arpt","flight_status","last_updt","flight_key"]
try:
    cursor.execute("select * from ASSESSMENT.FLIGHT_LEG")
except (Exception, psycopg2.DatabaseError) as error:
    print("Error : %s" % error)
    cursor.close()
    raise error
#Fetch all the data
flight_dt = cursor.fetchall()
cursor.close()

#Generate the data frame
flight_df = pd.DataFrame(flight_dt,columns=column_names)
flight_df.head()
flight_df['row_number'] = flight_df.groupby('flight_key').apply(lambda x: x.sort_values(by=['flight_dt', 'last_updt'], ascending=[False, False]).reset_index(drop=True).index + 1).reset_index(drop=True)
flight_filtered_df = flight_df[flight_df['row_number'] == 1].drop('row_number', axis=1)
flight_filtered_df.head()
#Close the DB Connection
conn.close()


